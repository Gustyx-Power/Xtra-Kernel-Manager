#!/system/bin/sh
# service.sh - Launcher

# 1. Definisikan folder module otomatis
MODDIR=${0%/*}

# 2. Beri izin eksekusi ke binary
chmod +x "$MODDIR/core_system"

# 3. Jalankan binary di background
MODDIR="$MODDIR" "$MODDIR/core_system" &
