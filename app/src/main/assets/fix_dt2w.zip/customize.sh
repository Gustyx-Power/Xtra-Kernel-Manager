#!/system/bin/sh

ui_print "- Mengatur permission..."

# 1. Set permission 
set_perm $MODPATH/system/usr/keylayout/Generic.kl 0 0 644
set_perm $MODPATH/product/overlay/oplus_framework_res_overlay.display.product.23861.apk 0 0 644
set_perm $MODPATH/sys/class/thermal/thermal_message/sconfig 0 0 444

ui_print "- Selesai."
